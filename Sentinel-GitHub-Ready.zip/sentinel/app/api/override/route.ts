import { NextResponse } from "next/server";
import { z } from "zod";
import { setOverride } from "@/lib/db";

export const runtime = "nodejs";
const schema = z.object({ paymentId: z.string().min(1), verdict: z.enum(["RELEASE", "HOLD"]) });

export async function POST(request: Request) {
  const parsed = schema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid override." }, { status: 400 });
  const result = setOverride(parsed.data.paymentId, parsed.data.verdict);
  return result.ok
    ? NextResponse.json({ ok: true })
    : NextResponse.json({ error: result.error }, { status: 409 });
}

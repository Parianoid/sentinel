<div align="center">

# 🛡️ Sentinel

### Human-governed AI trust layer for B2B payments

**Detect suspicious invoices before they become outgoing payments.**

Built for the **PayPal AI Hackathon 2026** · Next.js 15 · TypeScript · SQLite · Groq · PayPal Sandbox

[Get started](#quick-start) · [Architecture](#how-it-works) · [Demo](docs/DEMO.md) · [Setup guide](SETUP.md) · [API](openapi.yaml)

</div>

---

## Why Sentinel?

Accounts-payable teams can face duplicate invoices, changed beneficiary details, unusually large payment requests, and urgent messages designed to bypass review. Sentinel adds a **review and risk-decision layer** between an invoice queue and a Sandbox payout.

This is an **interactive hackathon prototype**, not a production payment or fraud-prevention service. All bundled vendors, invoices, and risk scenarios are synthetic.

## What it does

| Capability | Implementation |
| --- | --- |
| **Payment approval queue** | Vendor-grouped AG Grid table with search, risk signals, and evidence drawer |
| **Deterministic guardrails** | Duplicate-invoice hold; payee-change, new-vendor, and amount-anomaly flags |
| **AI-assisted assessment** | Optional Groq (`llama-3.1-8b-instant`) explanation, with Zod-validated output |
| **Human oversight** | Manual HOLD/RELEASE review; duplicate-invoice holds cannot be overridden |
| **Sandbox disbursements** | Server-side PayPal Payouts batch creation and payout-item reconciliation |
| **Audit experience** | Results screen, provider references, and CSV export |
| **Live demo controls** | Deterministic mode and "Inject attack" test scenario |

## Quick start

**Requirements:** Node.js 22+ and npm.

```bash
git clone https://github.com/Parianoid/sentinel.git
cd sentinel
npm ci
cp .env.example .env.local    # Windows PowerShell: Copy-Item .env.example .env.local
npm run dev
```

Visit **http://localhost:3000/queue**. Choose **Deterministic demo** and click **Run Sentinel**. No external keys are required to evaluate the synthetic demo queue. The SQLite database seeds itself on first use.

To enable **Live AI**, configure `GROQ_API_KEY`. To test **actual Sandbox payouts**, provide your PayPal Sandbox credentials and payout recipients. See [SETUP.md](SETUP.md). No funds move unless the user runs the release workflow and Sandbox credentials are configured.

## How it works

```mermaid
flowchart TD
    A[Seeded vendors and invoice requests] --> B[Payment approval queue]
    B --> C[Deterministic risk flags]
    C --> D[Deterministic assessment or optional Groq AI]
    D --> E[Human review]
    E --> F{Effective decision}
    F -->|HOLD or ESCALATE| G[No payout]
    F -->|RELEASE| H[Server-side eligibility check]
    H --> I[PayPal Sandbox Payouts batch]
    I --> J[Polling and verified webhooks]
    J --> K[Results and audit]
```

**Release protection:** A duplicate-invoice signal is a hard hold even if an old or malformed manual override exists. Other escalated signals still require a human decision; they are not automatically approved.

## Demo in three minutes

1. Open **Payment queue** — the seeded data includes normal invoices and four distinct suspicious patterns.
2. Select **Run Sentinel** — deterministic assessment marks 14 routine payments `RELEASE`, two `HOLD`, and two `ESCALATE`.
3. Open the **Acme Steel** suspicious payment — examine changed beneficiary details, anomalous amount, and urgent language.
4. Show that a **duplicate invoice remains held**; demonstrate manual review of an escalation.
5. Optionally attempt **Release approved** to demonstrate PayPal Sandbox Payouts. Without payout credentials, rows are flagged as pending setup and must not be presented as settled.
6. Visit **Results & audit**, export CSV, or click **Inject attack** to create another synthetic case.

For judge-friendly narration and expected outcomes, use [docs/DEMO.md](docs/DEMO.md).

## Repository map

```text
app/                 Next.js pages, dashboard components, and API routes
lib/                 Risk engine, seeded data, SQLite, PayPal integrations
openapi.yaml         OpenAPI 3.0 API description
SETUP.md             Groq and PayPal Sandbox configuration
SECURITY.md          Prototype security boundaries and cautions
docs/DEMO.md         Guided demo and troubleshooting
.github/workflows/   Continuous integration checks
```

## Validation

```bash
npm run typecheck
npm run build
```

These commands are also defined in [GitHub Actions](.github/workflows/ci.yml). The code requires normal dependency installation before local checks can run.

## Important limitations

- **Prototype only:** API routes have no authentication, authorization, rate limits, or multi-user approval identities. Run locally or behind access controls; do not publicly deploy this version.
- **Sandbox only:** The payout API host is restricted to PayPal Sandbox. Payment state depends on the Sandbox account's Payouts entitlement, balance, and webhook setup.
- **Demo storage:** Local SQLite and synthetic seeded data are not a multi-tenant or production audit ledger.
- **AI explains; rules enforce:** A model assessment is advisory and is not an identity-verification substitute.
- **Not proof of payment:** `PROCESSING` or `SANDBOX_PENDING` is not a successful transfer. Only confirmed `SETTLED`/`RELEASED` records count as completed.
- **Historical demonstration endpoints:** PayPal Orders/capture examples remain in the codebase; the outgoing vendor-payment flow uses **Payouts**, not Orders.

## Technology

Next.js App Router, React 19, strict TypeScript, Tailwind CSS, AG Grid Community, Zod, `better-sqlite3`, Groq via the OpenAI-compatible API, PayPal Agent Toolkit, and PayPal Payouts REST APIs.

## License

No open-source license has been assigned. Source is shared for hackathon demonstration; usage permissions are not granted by publication alone.

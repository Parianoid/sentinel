# Security guidance

Sentinel is a **hackathon prototype intended for local demonstrations and PayPal Sandbox testing only**. It is not audited, production ready, or suitable for unattended payments.

## Important boundaries

- API endpoints such as assessment, override, injection, and release do **not** authenticate users or enforce roles. Do not host the application on the public internet without implementing authentication, authorization, and CSRF defenses appropriate to the deployment.
- The Payouts API client refuses any host other than `https://api-m.sandbox.paypal.com`. The Orders demonstration is also configured for Sandbox.
- Secrets belong in `.env.local`, which Git excludes. Only `.env.example` with blank placeholders should be committed.
- The SQLite database and local audit files are ignored by Git and should not be shared with public demos containing actual business data.
- A duplicate-invoice deterministic signal is a hard hold enforced at the manual-override endpoint, in the effective queue decision, and again before payout.
- Other manual overrides are illustrative only; the application does not verify the identity of the approver or evidence of out-of-band confirmation.
- Webhook processing depends on PayPal signature verification and correct Sandbox webhook configuration.
- Never interpret `PROCESSING` or `SANDBOX_PENDING` as payment success. Only reconciled terminal settlement counts.

## Before any real deployment

Add identity and access management, maker-checker approvals, a separate immutable audit store, rate limiting, secure webhook replay handling, tested concurrency and idempotency controls, live-vs-test isolation, observability, error handling, and a full security review. This list is not exhaustive.

## Responsible disclosure

If you notice a security defect, contact the repository maintainer privately rather than posting passwords, tokens, or sensitive details in a public GitHub issue.

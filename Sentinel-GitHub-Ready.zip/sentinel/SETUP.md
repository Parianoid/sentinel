# Setup and configuration

This guide covers the **local hackathon demo** and optional external integrations. Never commit API keys, PayPal account secrets, or local database files.

## 1. Run deterministic mode (no credentials)

```bash
npm ci
cp .env.example .env.local       # PowerShell: Copy-Item .env.example .env.local
npm run dev
```

Open `http://localhost:3000/queue` and select **Deterministic demo**. Click **Run Sentinel**. The first request seeds 18 synthetic payment requests and vendor histories in the local SQLite database.

Expected initial decisions: **14 RELEASE · 2 HOLD · 2 ESCALATE**. These are risk decisions only, **not confirmed payouts**.

## 2. Optional: live Groq risk explanations

Create a Groq API key and add it to `.env.local`:

```dotenv
GROQ_API_KEY=your_groq_api_key
```

Restart the development server, select **Live AI**, and run an assessment. The implementation uses Groq's OpenAI-compatible API, `llama-3.1-8b-instant`, JSON Object Mode, and Zod response validation. Deterministic hard stops apply after the model's suggested verdict.

Live AI requires provider availability, quota, and access to the specified model; the deterministic demo continues to work without it.

## 3. Optional: PayPal Sandbox Payouts

1. At the [PayPal Developer Dashboard](https://developer.paypal.com/dashboard/), create or select a **Sandbox Business** account.
2. Create a Sandbox REST app for that merchant and retrieve its **Client ID** and **Secret**.
3. Ensure **Payouts** is enabled/authorized for that Sandbox account and it has adequate test balance. These permissions can vary by account.
4. Create one to three **Sandbox Personal** recipient accounts; collect their emails.
5. Add the following to `.env.local`:

```dotenv
PAYPAL_CLIENT_ID=your_sandbox_client_id
PAYPAL_SECRET=your_sandbox_secret
PAYPAL_CLIENT_SECRET=your_sandbox_secret
PAYPAL_ENVIRONMENT=SANDBOX
PAYPAL_API_BASE=https://api-m.sandbox.paypal.com
PAYOUT_RECIPIENTS=recipient1@example.com,recipient2@example.com
CURRENCY=USD
```

`PAYPAL_CLIENT_SECRET` is accepted as an alternative for the payout flow and used by the legacy Orders/capture demonstration endpoint. **Both values must refer to a Sandbox app.** Never point `PAYPAL_API_BASE` at a Live host.

Run a low-value approved test first. **Release approved** triggers one server-side Payouts batch; statuses remain `PROCESSING` until PayPal reports success/failure. `SANDBOX_PENDING` signals missing setup or indeterminate outcomes, not a completed transfer.

## 4. Optional: webhook verification

Expose the local server over an HTTPS development tunnel. In the PayPal Developer Dashboard, register:

```text
https://YOUR-TUNNEL.example/api/webhooks/paypal
```

Subscribe to payout-item events such as `PAYMENT.PAYOUTS-ITEM.SUCCEEDED`, `.FAILED`, `.BLOCKED`, and `.RETURNED`, and to relevant batch status events. Copy the webhook ID:

```dotenv
PAYPAL_WEBHOOK_ID=your_sandbox_webhook_id
```

The webhook handler validates PayPal signature verification before updating payment status. Use Sandbox-originated test events; do not assume local status is final before provider reconciliation.

## 5. Quality checks

```bash
npm run typecheck
npm run build
```

## Reset local demo state

Stop the server, delete `sentinel-v2.db` (or the file named by `SENTINEL_DB_FILE`) and restart the app. This **irreversibly discards** the local assessment, payout claims, and audit state, so only reset a disposable demo environment.

## Security and operational cautions

The app intentionally lacks production authentication, tenant isolation, payment approval identities, and API throttling. It is **not safe to expose publicly** or connect to real accounts. See [SECURITY.md](SECURITY.md).

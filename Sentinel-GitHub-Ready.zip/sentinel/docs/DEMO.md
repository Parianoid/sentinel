# Sentinel — 3-minute hackathon demonstration

## Setup

Run `npm ci`, copy `.env.example` to `.env.local`, then `npm run dev`. Open `http://localhost:3000/queue` and keep **Deterministic demo** selected for a predictable walkthrough.

## Narrative

**Problem (20 seconds).** Vendor payments can look legitimate while hiding a duplicate invoice, changed beneficiary, an unusually large amount, or social-engineering pressure. A generic approval queue doesn't prioritize the right cases.

**Detection (50 seconds).** Click **Run Sentinel**. The synthetic 18-item queue should show **14 RELEASE**, **2 HOLD**, and **2 ESCALATE**. Open the suspicious Acme payment and inspect payee change, amount deviation, urgent language, and the recommendation to verify on a known-good channel.

**Governance (40 seconds).** Show the duplicate-invoice hard hold. A human can review escalated invoices but cannot override a duplicate to RELEASE through the API. Explain that AI outputs do not decide settlement on their own.

**Disbursement (40 seconds).** With correctly configured PayPal Sandbox credentials and Payouts permission, use **Release approved**. Explain that the backend checks eligibility again, creates a claim for each selected payment, and sends a Payouts batch. Without credentials, this step is **setup pending**, not a successful transfer.

**Evidence (30 seconds).** Open **Results & audit**, inspect provider references/statuses, export CSV, and optionally use **Inject attack** to create an additional fraudulent request.

## Seeded scenarios

| Scenario | Key evidence | Default risk decision |
| --- | --- | --- |
| 14 standard invoice requests | Known payee and historically plausible amount | RELEASE |
| Acme bank-change attack | Changed payee, very high amount, urgency | HOLD |
| Northstar repeated invoice | Same vendor and invoice number as previous request | HOLD — cannot override |
| Nova first-time high-value vendor | No payment history and high amount | ESCALATE |
| Harbor unusual invoice amount | Existing payee but payment is far above history | ESCALATE |

**Important distinction:** `RELEASE` in the risk queue means eligible for the *next* step, not that PayPal has paid. Only provider-confirmed settlement is payment success.

## If the demo isn't behaving as expected

- **Live AI returns an error:** Switch to deterministic mode; check `GROQ_API_KEY` and access/quota.
- **Payouts unavailable:** Confirm Sandbox credentials, recipient emails, Payouts entitlement, and merchant balance.
- **Payments stuck at processing:** Check Sandbox status, webhook verification, and polling.
- **The queue has different counts:** The local SQLite database persists previous assessments and injected attacks; reset only in a disposable environment using the procedure in [SETUP.md](../SETUP.md).
